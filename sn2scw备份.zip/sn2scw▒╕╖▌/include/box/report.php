<?php

!(defined('IN_MYMPS')) && exit('FORBIDDEN');
require_once MYMPS_DATA . '/report.type.inc.php';
include MYMPS_ROOT . '/template/box/report.html';

?>
