<?php

!(defined('IN_MYMPS')) && exit('FORBIDDEN');
require_once MYMPS_ROOT . $admindir . '/include/mymps.menu.inc.php';
include MYMPS_ROOT . '/template/box/adminmenu.html';
unset($admindir);

?>
