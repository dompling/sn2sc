<?php

!(defined('IN_MYMPS')) && exit('FORBIDDEN');
include MYMPS_ROOT . '/template/box/goodsorder.html';

?>
