<?php
$htmlstyle[news] = '/{year}{month}/article_{id}.html';
?>