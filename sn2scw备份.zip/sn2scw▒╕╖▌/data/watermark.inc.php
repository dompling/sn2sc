<?php
$photo_markup 	= $mymps_global['cfg_upimg_watermark']  ? $mymps_global['cfg_upimg_watermark'] : '1'; 
$photo_markdown = '1';
$photo_wwidth 	= $mymps_global['cfg_upimg_watermark_width'] ? $mymps_global['cfg_upimg_watermark_width'] : '22';
$photo_wheight 	= $mymps_global['cfg_upimg_watermark_height']  ? $mymps_global['cfg_upimg_watermark_height'] : '22';
$photo_waterpos = $mymps_global['cfg_upimg_watermark_position'] ? $mymps_global['cfg_upimg_watermark_position'] : '9';
$photo_watertext = $mymps_global['cfg_upimg_watermark_text'] ? $mymps_global['cfg_upimg_watermark_text'] :
'http://www.mymps.com.cn';
$photo_fontsize = $mymps_global['cfg_upimg_watermark_size'] ? $mymps_global['cfg_upimg_watermark_size'] :  '12'; 
$photo_fontcolor = $mymps_global['cfg_upimg_watermark_color'] ? $mymps_global['cfg_upimg_watermark_color'] : '#0000FF';
$photo_diaphaneity 	= $mymps_global['cfg_upimg_watermark_diaphaneity'] ? $mymps_global['cfg_upimg_watermark_diaphaneity'] : '60';
$photo_markimg 	= $mymps_global['cfg_upimg_watermark_img'];
?>