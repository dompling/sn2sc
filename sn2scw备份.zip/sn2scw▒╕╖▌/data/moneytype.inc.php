<?php
if (!defined('IN_MYMPS')){
    die('FORBIDDEN');
}
/*商品网购的money单位*/
$moneytype ='元';

?>