<? if(!defined('IN_MYMPS')) exit('Access Denied');
/*Mymps分类信息系统
官方网站：http://www.mymps.com.cn*/?>
<!DOCTYPE html>
<html lang="zh-CN" class="index_page">
<head>
<?php include mymps_tpl('header'); ?>
<title>会员登录 - <?=$mymps_global['SiteName']?></title>
<link type="text/css" rel="stylesheet" href="template/css/global.css">
<link type="text/css" rel="stylesheet" href="template/css/style.css">
<link type="text/css" rel="stylesheet" href="template/css/login.css">
<script>window['current'] = '会员登录';</script>
<script>function checksubmit(o){if($("#userid").val()===""){alert("请输入登录账号/邮箱地址/手机号！");$("#userid").focus();removewarn();$("#loginUserNameLi").css('border-color','#FF0000');return false}else{var lenth=lenthString($("#userid").val());if(lenth<3||lenth>15){alert('账号不得小于3个字符或大于15个字符！');$("#userid").focus();removewarn();$("#loginUserNameLi").css('border-color','#FF0000');return false}}if($("#userpwd").val()===""){alert("请输入登录密码！");$("#userpwd").focus();removewarn();$("#loginPasswordLi").css('border-color','#FF0000');return false}<? if($authcodesettings['login']==1) { ?>if($('#checkcode').val()===""){$("#checkcode").focus();removewarn();$("#loginCheckcodeLi").css('border-color','#FF0000');alert("请输入验证码！");return false}<?php } ?>return true;}function removewarn(){$(".passport-login-input-li").css('border-color','#c0c1c2');}function chk_authcode(){var checkcode=$("#checkcode").val();var url='../javascript.php?part=chk_authcode&value='+checkcode;if(checkcode){$.get(url,function(data){if(data==='success'){return true;}else{alert(data);$("#checkcode").focus();removewarn();$("#loginCheckcodeLi").css('border-color','#FF0000');return false;}});}}function usewxlogin(){if(is_wxclient()){window.location.href='<?=$mymps_global['SiteUrl']?>/include/wxlogin/wxlogin.php';}else{alert('请在微信客户端中使用微信登录！')}}</script>
</head>

<body class="<?=$mymps_global['cfg_tpl_dir']?>">
<div class="wrapper">
<?php include mymps_tpl('header_search'); ?>
  	<!--<div class="dl_nav"><span><a href="index.php">首页</a><font class="raquo"></font><a href="javascript:;">登录</a></span></div>--> 
  	<div class="m311 log_reg_box">
<div id="logRegTabCon">
<div class="log_reg_item">  
<form id="form1" method="post" action="index.php?mod=login&action=login" onSubmit="return checksubmit(this);">
<input type="hidden" name="returnurl" value="<?=$returnurl?>">
<ul id="pptul" class="passport-login-input-ul">
<li style="display:none" class="passport-login-input-li">
<span id="loginTip" class="passport-login-tip"></span>
</li>

<li id="loginUserNameLi" class="passport-login-input-li">
<span class="passport-login-input-span">账&nbsp;&nbsp;&nbsp;&nbsp;号</span>
<input autocomplete="off" id="userid" type="text" name="userid" class="passport-login-input passport-login-input-username" placeholder="账号/邮箱/手机">
</li>

<li id="loginPasswordLi" class="passport-login-input-li">
<span class="passport-login-input-span">密&nbsp;&nbsp;&nbsp;&nbsp;码</span>
<input autocomplete="off" id="userpwd" type="password" name="userpwd" class="passport-login-input passport-login-input-password" placeholder="密码">
</li>

                	<? if($authcodesettings['login'] == 1) { ?>
<li id="loginCheckcodeLi" class="passport-login-input-li">
<span class="passport-login-input-span">验证码</span>
<input autocomplete="off" type="text" onBlur="chk_authcode()" id="checkcode" name="checkcode" class="passport-login-input passport-login-input-username"  style="width:130px;" placeholder="图中验证码" size="20" maxlength="75">
</li>
                    <div style="margin-top:10px; text-align:center">
                    	<img src="<?=$mymps_global['SiteUrl']?>/<?=$mymps_global['cfg_authcodefile']?>?mod=m" alt="看不清，请点击刷新" align="absmiddle" style="cursor:pointer; border:1px #ddd solid;" onClick="this.src=this.src+'?'"/>
                    </div>
<?php } ?>

<li id="loginButtonLi" class="passport-login-input-li">
<span class="passport-login-input-span" jqmoldstyle="block" style="display: none;">&nbsp;</span>
<label><input type="submit" name="button" value="登录" class="passport-login-button btn_log"></label>
</li>
</ul>
</form>
</div>
</div>
<div class="login_ff">
  <div class="login_ffmain">
  <a class="login_ffleft" href="index.php?mod=register">免费注册</a>
  </div>
          <? if($qqlogin['open'] == 1 || $wxlogin['open'] == 1) { ?>
      <div class="login_hezuo">
  使用合作网站账号登录：
  <div class="login_hezuo_mian">
              	<? if($wxlogin['open'] == 1) { ?>
                <ul>
<li class="bor" style=" margin:0 auto; float:none; border:none"><a href="javascript:void(0);" onClick="usewxlogin();"><i class="hzico-wx"></i>使用微信账号登录</a></li>
</ul>
                <?php } ?>
              	<? if($qqlogin['open'] == 1) { ?>
<ul>
<li class="bor" style=" margin:0 auto; float:none; border:none"><a href="<?=$mymps_global['SiteUrl']?>/include/qqlogin/qq_login.php?mod=m"><i class="hzico-qq"></i>使用QQ账号登录</a></li>
</ul>
                <?php } ?>
  </div>
  </div>
          <?php } ?>
</div>
  	</div>
</div>
<?php include mymps_tpl('footer'); ?>
</body>
</html>