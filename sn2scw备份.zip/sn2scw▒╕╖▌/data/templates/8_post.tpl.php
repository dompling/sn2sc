<? if(!defined('IN_MYMPS')) exit('Access Denied');
/*Mymps分类信息系统
官方网站：http://www.mymps.com.cn*/?>
<!DOCTYPE html>
<html lang="zh-CN" class="index_page">
<head>
<?php include mymps_tpl('header'); ?>
<title>发布信息 - <?=$mymps_global['SiteName']?></title>
<link type="text/css" rel="stylesheet" href="template/css/global.css">
<link type="text/css" rel="stylesheet" href="template/css/style.css">
<link type="text/css" rel="stylesheet" href="template/css/post.css">
<link type="text/css" rel="stylesheet" href="template/css/plugin_tuya.css">
<link type="text/css" rel="stylesheet" href="template/css/plugins/uploadImg.css">
<script src="<?=$mymps_global['SiteUrl']?>/template/default/js/jquery.min.js" type="text/javascript"></script>
<script src="http://res.wx.qq.com/open/js/jweixin-1.4.0.js"></script>
<script src="template/js/plugin/uploadImg.js"></script>
<script src="template/js/plugin/tuya.js" type="text/javascript"></script>
<!-- <script src="template/js/jssdk.js" type="text/javascript"></script> -->
<script>window['current'] = '<? echo $id ? "修改" : "发布"; ?>信息';</script>
<script language="javascript">
function submitForm(){if(document.form1.title.value==""){alert('请填写信息标题!');document.form1.title.focus();return false}if($("#title").val()){if(!isNaN($("#title").val())){alert('请填写正确的信息标题!');$("#title").focus();return false}}var length=lenthString($("#title").val());if(length<6||length>80){alert('请填写至少3个汉字，至多40个汉字!');$("#title").focus();return false}if(document.form1.endtime.value==""){alert('请选择有效期!');document.form1.endtime.focus();return false}<?php if(is_array($show_mod_option)){foreach($show_mod_option as $mymps) { if($mymps['required']==1) { ?>if($("[name='extra[<?=$mymps['identifier']?>]']").val()==''){alert('<?=$mymps['title']?>不能为空!');$("[name='extra[<?=$mymps['identifier']?>]']").focus();return false}<?php } ?><?php }} ?>if(document.form1.contact_who.value==""){alert('请填写联系人!');document.form1.contact_who.focus();return false}if($("#contact_who").val()){if(!isNaN($("#contact_who").val())){alert('请填写正确的联系人!');document.form1.contact_who.focus();return false}}if(document.form1.tel.value==""){alert('请填写联系电话!');document.form1.tel.focus();return false}if($("#qq").val()){if(isNaN($("#qq").val())){alert('请填写正确的QQ号码!');document.form1.qq.focus();return false}}if(document.form1.content.value==""){alert('请填写信息内容!');document.form1.content.focus();return false}var lenth=lenthString($("#content").val());if(lenth<10){alert('请填写至少5个汉字!');$("#content").focus();return false}if(lenth>1000){alert('您的描述字数太多了，请精简内容描述!');$("#content").focus();return false}<? if($iflogin==0) { ?>if(document.form1.manage_pwd.value==""){alert('请填写管理密码!');document.form1.manage_pwd.focus();return false}<?php } if($info['imgcode']==1) { ?>if(document.form1.checkcode.value==""){alert('请填写验证码!');document.form1.checkcode.focus();return false;}<?php } ?>$("#loadingPostdiv").show();return true}function chk_authcode(){if($("#checkcode").val()){$.get('../javascript.php?part=chk_authcode&value='+$("#checkcode").val(),function(data){if(data!='success'){alert(data);$("#checkcode").focus();return false}})}}function loadingPost(){var _PageWidth=document.documentElement.clientWidth;var _LoadingLeft=_PageWidth>215?(_PageWidth-215)/2:0;var _LoadingHtml='<div id="loadingPostdiv" style="display:none;position:fixed;left:0;width:100%;height:100%;top:0;background:#e1e1e1;opacity:0.8;filter:alpha(opacity=80);z-index:10000;"><div style="position: absolute; cursor1: wait; left: '+_LoadingLeft+"px; top:40%; width: auto; height: 57px; line-height: 57px; padding-left: 40px; padding-right: 20px; background:#ffffff url(../images/loading.gif) no-repeat scroll 15px 20px; border: 5px solid #CCCCCC; border-radius:5px; color: #000;font-size:14px;\">数据提交中，请等待...</div></div>";document.write(_LoadingHtml)}loadingPost();
</script>
</head>
<body class="<?=$mymps_global['cfg_tpl_dir']?>">
<div class="wrapper">
<?php include mymps_tpl('header_search'); ?>
    <form id="form1" method="post" enctype="multipart/form-data" action="index.php?mod=post" name="form1"  onSubmit="return submitForm();">
    <? if(empty($child)) { ?><input name="catid" type="hidden" value="<?=$catid?>"><?php } ?>
    <input name="id" type="hidden" value="<?=$id?>">
    <input name="action" type="hidden" value="post">
    <input type="hidden" value="<?=$mixcode?>" name="mixcode"/>
    <input type="hidden" id="lat" name="lat" value="">
    <input type="hidden" id="lng" name="lng" value="">
    <!--填写信息-->
 <div class="inp_Itembox">
  <dl class="cfix">
   <dt>类别</dt>
   <dd><?=$info['catname']?> <? if(!$id) { ?><a href="index.php?mod=post">(重选)</a><?php } ?></dd>
  </dl>
  <dl class="cfix">
   <dt>标题</dt>
   <dd><input name="title" id="title" type="text" size="26" value="<?=$info['title']?>" placeholder="输入标题，40字以内" />
     <br>
     请填写品牌车系车型（款式）<br>
   </dd>
  </dl>
  <dl class="cfix">
   <dt>区域</dt>
   <dd><select name='areaid' id='areaid' >
   <option value=''>请选择区域</option>
   <? echo cat_list('area','',$info['areaid']);; ?>   </select></dd>
   <div class="menu">
    <i></i>
    <i></i>
    <i></i>
   </div>
  </dl>
  <dl class="cfix">
   <dt>有效期</dt>
   <dd><? echo GetInfoLastTime($info['activetime'],'endtime','wap'); ?></dd>
   <div class="menu">
    <i></i>
    <i></i>
    <i></i>
   </div>
  </dl>
 </div>

 <div class="inp_Itembox">
 <?php if(is_array($show_mod_option)){foreach($show_mod_option as $mymps) { ?>  <dl class="cfix">
   <dt><?=$mymps['title']?></dt>
   <dd>
<?=$mymps['value']?>
    <? if(strstr($mymps['value'],'select')) { ?>
<div class="menu">
    <i></i>
    <i></i>
    <i></i>
   </div>
   <?php } ?>
   </dd>
  </dl>
  <?php }} ?>
 </div>

 <div class="inp_Itembox">
   <dl class="cfix">
   <dt>联系人</dt>
   <dd><input type="text" id="contact_who" placeholder="输入联系人" name="contact_who" value="<?=$info['contact_who']?>" /></dd>
  </dl>
  <dl class="cfix">
   <dt>手机</dt>
   <dd><input type="text" id="tel" placeholder="请输入手机号码" name="tel" value="<?=$info['tel']?>" /></dd>
  </dl>
  </div>

<? if($cat['if_upimg']==1) { ?>
<!-- <script type="text/javascript" src="/template/default/js/a_ddimgview.js"></script> -->
<div class="inp_Itembox" style="overflow:auto; padding:10px 0 10px 10px">
<table width="100%" cellspacing="0" cellpadding="0">
<tr>
    <style>
        .bigImages{
            position:absolute;
            z-index:99px;
            width:100%;
            height:100%;
        }
        .bigImages img{
            width:100%;
            height:100%
        }
    </style>
<td colspan="2">
 <div class="p-line">
      <p><label class="p-label">上传图片：</label></p>
      <div class="publish-detail-item">
          <div id="Pic_pass">
              <p><span style="color: red;font-size:12px;">注：每张照片大写不可超过4M</span></p>
              <div class="picDiv">
                  <!-- <div class="bigImages">
                      <img src="http://draw.djm6.com/attachment/information/201901/1546486480fgtih.jpg" alt="123" srcset="">
                  </div> -->
                <div class="addImages">
                  <input  type="file" name="file[]" multiple accept="image/png, image/jpeg, image/gif, image/jpg" class="file" id="fileInput">
                  <div class="text-detail" >
                    <span class="add">+</span>
                    <p>点击上传</p>
                  </div>
                </div>
              </div>
          </div>
      </div>
    </div>
</td>
</tr>
</table>
 </div>

<?php } ?>
<!-- 涂鸦BEGIN -->
<div id="canvas_graffiti" style="display:none;border-bottom:1px solid #3592E2;position:fixed;top:45px;left:0;background:#f5f5f5;Z-index:1000;opacity:1;min-height:520px;width:100%;">
    <canvas id="canvas" width="300" height="400" style="border:1px solid #999;position:absolute;top:10px;left:0px;right:0;margin:0 auto;"></canvas>
    <canvas id="canvas2" width="300" height="400" style="border:1px solid #999;position:absolute;top:10px;left:0px;right:0;margin:0 auto;"></canvas>
    <div style="width:80%;padding:0 10%;position:absolute;left: 0px;top:430px;display: flex;justify-content: space-around;">
    	<span id="btn_draw"  class="btn" style="width:70px;height: 30px;border: 1px solid #ccc;border-radius:5px;background: #f1f1f1;color: #3592E2;line-height:30px;text-align: center;">涂鸦</span>
    	<span id="btn_wipe" class="btn"  style="width:70px;height: 30px;border: 1px solid #ccc;border-radius:5px;background: #f1f1f1;color: #3592E2; line-height:30px;text-align: center;">橡皮擦</span>
    	<span id="btn_clear" class="btn"  style="width:70px;height: 30px;border: 1px solid #ccc;border-radius:5px;background: #f1f1f1;color: #3592E2;line-height:30px;text-align: center;">清除</span>
    </div>
    <div id="cavas_btn" style="width:80%;padding:0 10%;position:absolute;left: 0px;top:480px;display: flex;justify-content: space-around;">
    		<input style="width:80px;height: 30px;border:none;border-radius: 3px;background: #3592E2;color: #fff;" type="button" value="保存" id="save"/>
    		<input style="width:80px;height: 30px;border:none;border-radius: 3px;background: #3592E2;color: #fff;" type="button" name="" id="quxiao"  value="取消"/>
    </div>
     <div id="forbiden_back" style="width: 100%;height: 100%;background-image: url(template/img/pattern.png);position: absolute;top: 0px;left: 0px;display: none;">
        <div style="width: 382px;height: 170px;background-image: url(template/img/open_window.png);margin: 0 auto;margin-top: 200px;position: relative;">
            <input id="pic_url" type="file" style="width:250px; margin: 53px;margin-left: 83px;" />
            <div id="close_window" style="width: 20px;height: 15px;border: 0px solid green;position: absolute;right:20px;top: 10px"></div>
            <div id="open_pic" style="width: 80px;height: 30px;border: 0px solid green;position: absolute;left:155px;top: 102px"
                onClick="open_img(pic_url)"></div>
        </div>
    </div>
</div>
<!-- 涂鸦END -->
<div class="inp_Itembox">
<textarea class="txt" id="content" name="content" placeholder="输入描述文字，不能超过500字"><?=$info['content']?></textarea>
    <? if($iflogin == 0) { ?>
    <dl class="cfix">
        <dt>管理密码</dt>
        <dd><input name="manage_pwd" type="text" size="26" value="" placeholder="请牢记，用于修改/删除该信息"/>
          <br>
        用于修改/删除该信息</dd>
    </dl>
    <?php } ?></div>


<? if($info['imgcode'] == 1) { ?>
<div class="inp_Itembox">
<dl class="cfix">
    <dt>验证码</dt>
    <dd><input id="checkcode" name="checkcode" onBlur="chk_authcode()" placeholder="请输入下图验证码" type="text" size="26" /><img src="<?=$mymps_global['SiteUrl']?>/<?=$mymps_global['cfg_authcodefile']?>?mod=m" alt="看不清，请点击刷新" class="authcode" align="absmiddle" onClick="this.src=this.src+'?'"/></dd>
</dl>
</div>
<?php } ?>

<button type="submit" class="fb"><? echo $id ? "保存修改" : "提交发布"; ?></button>
</form>
</div>
<?php include mymps_tpl('footer'); ?>
<script>
if(navigator.geolocation){navigator.geolocation.getCurrentPosition(showPosition)}else{}function showPosition(position){document.getElementById("lat").value=position.coords.latitude;document.getElementById("lng").value=position.coords.longitude}
</script>

</body>
</html>
<script type="text/javascript">
    $(function(){
        var ua = navigator.userAgent.toLowerCase();
        // alert(ua);
        if(ua.match(/MicroMessenger/i) =="micromessenger" && ua.match(/android/i) == 'android') {
           $(".addImages").children("input[type='file']").remove();
            $(".add").click(function(){
                getImg();
            })
        }
    })
    wx.config({
        debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
        appId: '<?=$JssdkConfig["appId"]?>', // 必填，公众号的唯一标识
        timestamp: <?=$JssdkConfig['timestamp']?>, // 必填，生成签名的时间戳
        nonceStr: '<?=$JssdkConfig["nonceStr"]?>', // 必填，生成签名的随机串
        signature: '<?=$JssdkConfig["signature"]?>',// 必填，签名
        jsApiList: [
            'chooseImage',
            'previewImage',
            'uploadImage',
        ] // 必填，需要使用的JS接口列表
    });
    var picDiv = $('.file').parents(".picDiv");
    var list = [];
    function getImg(){
        wx.chooseImage({
            count: 9, // 默认9
            sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function (res) {
                console.log(res)
                var localIds = res.localIds; // 返回选定照片的本地ID列表，localId可以作为img标签的src属性显示图片
                var html = '';
                list = localIds;
                var chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz'; // 默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1
                var maxPos = chars.length;

                for(var i=0;i<localIds.length;i++){
                        var id = '';
                    for (a = 0; a < 4; a++) {
                        if(id.length<4){
                            id += chars.charAt(Math.floor(Math.random() * maxPos));
                        }
                    }
                    html += `<div class="imageDiv" onclick="previewImage(this)">
                                <img src="${localIds[i]}">
                                <div class='cover'><i class='delbtn' id="`+id+`" onclick="del(this)"><strong>X</strong></i></div>
                            </div>`;
                    uploadImg(localIds[i],id);
                }
                picDiv.prepend(html);
            }
        });
    }
    //上传到微信服务器
    function uploadImg(localId,id){
        wx.uploadImage({
            localId: localId, // 需要上传的图片的本地ID，由chooseImage接口获得
            isShowProgressTips: 1, // 默认为1，显示进度提示
            success: function (res) {
                var serverId = res.serverId; // 返回图片的服务器端ID
                downLoadImgData(serverId,id);
            }
        });
    }
    //下载到服务器
    function downLoadImgData(serverId,id){
        $.post("/upload_img.php?action=Wx",{"serverId":serverId},function(res){
            if(res.status){
                var html = '<input type="hidden" name="img[]" data="'+id+'" value="'+res.path+'">';
                $("#form1").prepend(html);
            }else{
                alert(res.info);
            }
        },'json');
    }
    //预览
    function previewImage(obj){
       /*  if($(obj).hasClass("imageDiv")){
            $(obj).removeClass('imageDiv').addClass("bigImages");
        }else{
            $(obj).removeClass('bigImages').addClass("imageDiv");
        } */
    }

function del(obj){
    var id = $(obj).attr('id');
    $(obj).parent().parent().remove();
    var inputArr = $("input[name='img[]']");
    for(var i = 0; i<inputArr.length;i++){
        if(inputArr.eq(i).attr('data') == id){
            inputArr.eq(i).remove();
        }
    }
}
</script>
