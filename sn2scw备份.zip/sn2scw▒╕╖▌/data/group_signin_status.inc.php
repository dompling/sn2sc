<?php
$status = array('0'=>'<font color="blue">无效报名</font>','1'=>'<font color="red">接受报名</font>');
?>