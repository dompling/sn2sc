<?php
$information_tpl = array(
	'info'=>'通用模板',
	'info_zp'=>'招聘模板',
	'info_resume'=>'简历模板'
);
?>