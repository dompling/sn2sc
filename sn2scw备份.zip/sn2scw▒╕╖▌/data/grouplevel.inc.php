<?php
$glevel = array();
$glevel[0] = '<font color=red>待审核</font>';
$glevel[1] = '<font color=#006acd>审核通过</font>';
$glevel[2] = '<font color=green>组团中</font>';
$glevel[3] = '<font color=#ff9900>活动流产</font>';
$glevel[4] = '<font color=#ff6600>活动结束</font>';
?>