<?php
$template = array();
$template['fengge']['flag']['blue'] = '蚂蚁蓝';
$template['fengge']['flag']['green'] = '赶集绿';
$template['fengge']['flag']['orange'] = '58橙';
$template['fengge']['flag']['red'] = '天猫红';

$template['banmian']['flag']['simple'] = '分类信息版';
$template['banmian']['flag']['portal'] = '地方门户版';
$template['banmian']['flag']['classic'] = '行业信息版';
?>