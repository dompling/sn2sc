<?php
$category_tpl = array(
	'list'=>'公共模板',
	'list_zhaopin'=>'招聘模板',
	'list_qiuzhi'=>'求职简历模板',
	'list_ershou'=>'物品转让模板',
	'list_house'=>'二手房模板',
	'list_zufang'=>'租房模板',
	'list_pet'=>'宠物狗模板',
	'list_simple'=>'简洁列表模板',
	'list_box'=>'块状模板'
);
?>