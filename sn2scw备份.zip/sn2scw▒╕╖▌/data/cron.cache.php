<?php
$m_cron = array (
  'information' => 
  array (
    'lastrun' => '1554134453',
    'nextrun' => '1554220800',
    'day' => '1',
  ),
  'advertisement' => 
  array (
    'lastrun' => '1554134453',
    'nextrun' => '1554220800',
    'day' => '1',
  ),
  'levelup' => 
  array (
    'lastrun' => '1554134453',
    'nextrun' => '1554220800',
    'day' => '1',
  ),
);
?>