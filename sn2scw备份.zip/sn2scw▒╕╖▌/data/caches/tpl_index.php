<?php
$data = array (
  'tpl_set' => 
  array (
    'banmian' => 'portal',
    'showstyle' => 
    array (
      228 => '1',
      264 => '1',
      265 => '1',
      266 => '1',
      267 => '1',
      268 => '1',
      269 => '1',
      270 => '1',
      271 => '1',
      272 => '1',
      273 => '1',
      274 => '1',
      275 => '1',
      276 => '1',
    ),
    'classic' => 
    array (
      'cats' => '10',
    ),
    'portal' => 
    array (
      'ershou' => '253',
      'ershoumod' => '2',
      'zufang' => '277',
      'zufangmod' => '23',
      'ershoufang' => '254',
      'ershoufangmod' => '22',
      'zhaopin' => '255',
      'zhaopinmod' => '7',
      'jianli' => '259',
      'jianlimod' => '9',
    ),
    'portali' => 
    array (
      'acreage' => 'acreage',
      'prices' => 'prices',
      'company' => 'company',
    ),
    'indextopinfo' => '12',
    'newinfo' => '0',
    'announce' => '8',
    'faq' => '0',
    'news' => '7',
    'foreachinfo' => '0',
    'goods' => '8',
    'telephone' => '16',
    'lifebox' => '16',
  ),
);
?>