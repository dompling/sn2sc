<?php
$data = array (
  'allow_tpl' => 
  array (
  ),
);
?>