<?php
$data = array (
  'settings' => 
  array (
    'forward' => 
    array (
      'information' => '1',
      'news' => '1',
      'goods' => '1',
      'group' => '1',
      'coupon' => '1',
    ),
  ),
);
?>