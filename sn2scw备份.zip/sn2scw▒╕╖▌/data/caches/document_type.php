<?php
$data = array (
  1 => 
  array (
    'typeid' => '1',
    'typename' => '商家资讯',
    'arrid' => '1',
  ),
  2 => 
  array (
    'typeid' => '2',
    'typename' => '优惠促销',
    'arrid' => '2',
  ),
);
?>