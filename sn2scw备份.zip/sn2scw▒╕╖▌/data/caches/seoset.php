<?php
$data = array (
  'seo_force_goods' => 'active',
  'seo_force_store' => 'active',
  'seo_force_space' => 'active',
  'seo_force_yp' => 'active',
  'seo_force_news' => 'active',
  'seo_force_info' => 'active',
  'seo_force_category' => 'active',
  'seo_keywords' => '遂宁二手车网',
  'seo_force_about' => 'active',
  'seo_description' => '遂宁二手车网你身边的懂车专家',
  'seo_sitename' => '遂宁二手车网吉老师你身边的懂车专家',
  'seo_html_make' => '',
);
?>