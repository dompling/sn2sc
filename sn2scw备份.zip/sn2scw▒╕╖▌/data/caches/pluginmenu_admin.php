<?php
$data = array (
  '资讯' => 
  array (
    '新闻管理' => 'news.php',
    '新闻类别' => 'channel.php',
    '新闻评论' => 'news_comment.php',
  ),
);
?>