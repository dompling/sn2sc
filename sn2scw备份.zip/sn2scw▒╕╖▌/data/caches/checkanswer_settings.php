<?php
$data = array (
  'whenpost' => '',
  'whenregister' => '',
);
?>