<?php
$data = array (
  'snow' => '',
  'line' => '0',
  'noise' => '0',
  'type' => 'number',
  'memberpost' => '1',
  'post' => '1',
  'forgetpass' => '1',
  'distort' => '5',
  'incline' => '5',
  'close' => '3',
  'number' => '4',
);
?>