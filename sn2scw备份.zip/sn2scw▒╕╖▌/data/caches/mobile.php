<?php
$data = array (
  'allowmobile' => '1',
  'register' => '1',
  'post' => '1',
  'mobiletopicperpage' => '10',
  'mobiledomain' => 'http://www.sn2scw.com/m',
);
?>