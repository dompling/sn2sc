<?php
$data = array (
  2 => 
  array (
    40 => 
    array (
      'title' => '二手车',
      'url' => 'index.php?mod=category&catid=228',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/icon_che.gif',
      'target' => '_self',
    ),
    39 => 
    array (
      'title' => '4s店新车',
      'url' => 'http://www.sn2scw.com/corporation.php?catid=7',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/icon_4s.gif',
      'target' => '_self',
    ),
    47 => 
    array (
      'title' => '汽修厂',
      'url' => 'http://www.sn2scw.com/corporation.php?catid=8',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/qxc.gif',
      'target' => '_self',
    ),
    45 => 
    array (
      'title' => '汽车配件',
      'url' => 'http://www.sn2scw.com/corporation.php?catid=9',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/pj.gif',
      'target' => '_self',
    ),
    60 => 
    array (
      'title' => '汽车轮胎',
      'url' => 'http://www.sn2scw.com/corporation.php?catid=74',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/lt.gif',
      'target' => '_self',
    ),
    41 => 
    array (
      'title' => '洗车美容',
      'url' => 'http://www.sn2scw.com/corporation.php?catid=69',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/mr.gif',
      'target' => '_self',
    ),
    42 => 
    array (
      'title' => '物流公司',
      'url' => 'http://www.sn2scw.com/corporation.php?catid=9',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/wl.gif',
      'target' => '_self',
    ),
    43 => 
    array (
      'title' => '个体货运',
      'url' => 'http://www.sn2scw.com/corporation.php?catid=67',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/hy.gif',
      'target' => '_self',
    ),
    44 => 
    array (
      'title' => '租赁公司',
      'url' => 'http://www.sn2scw.com/corporation.php?catid=68',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/zl.gif',
      'target' => '_self',
    ),
    59 => 
    array (
      'title' => '汽车驾校',
      'url' => 'http://www.sn2scw.com/corporation.php?catid=75',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/jx.gif',
      'target' => '_self',
    ),
    57 => 
    array (
      'title' => '代驾陪驾',
      'url' => 'http://www.sn2scw.com/corporation.php?catid=72',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/dj.gif',
      'target' => '_self',
    ),
    58 => 
    array (
      'title' => '拖车救援',
      'url' => 'http://www.sn2scw.com/corporation.php?catid=73',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/qcjy.gif',
      'target' => '_self',
    ),
    54 => 
    array (
      'title' => '加油加气',
      'url' => 'http://www.sn2scw.com/corporation.php?catid=70',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/jy.gif',
      'target' => '_self',
    ),
    56 => 
    array (
      'title' => '停车场',
      'url' => 'http://www.sn2scw.com/corporation.php?catid=71',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/tcc.gif',
      'target' => '_self',
    ),
    53 => 
    array (
      'title' => '热点资讯',
      'url' => 'index.php?mod=news',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/icon_news.gif',
      'target' => '_self',
    ),
    49 => 
    array (
      'title' => '我要发布',
      'url' => 'http://www.sn2scw.com/m/index.php?mod=post',
      'color' => '',
      'flag' => '',
      'ico' => '/template/default/images/index/icon_business.gif',
      'target' => '_self',
    ),
  ),
  1 => 
  array (
    4 => 
    array (
      'title' => '首页',
      'url' => 'index.php?mod=index',
      'color' => '',
      'flag' => 'index',
      'ico' => '',
      'target' => '_self',
    ),
    1 => 
    array (
      'title' => '信息分类',
      'url' => 'index.php?mod=category',
      'color' => '',
      'flag' => 'category',
      'ico' => '',
      'target' => '_self',
    ),
    2 => 
    array (
      'title' => '热点资讯',
      'url' => 'index.php?mod=news',
      'color' => '',
      'flag' => 'news',
      'ico' => '',
      'target' => '_self',
    ),
    3 => 
    array (
      'title' => '商家店铺',
      'url' => 'index.php?mod=corp',
      'color' => '',
      'flag' => 'corp',
      'ico' => '',
      'target' => '_self',
    ),
    55 => 
    array (
      'title' => '商品展示',
      'url' => 'index.php?mod=goods',
      'color' => '',
      'flag' => 'goods',
      'ico' => '',
      'target' => '_self',
    ),
  ),
);
?>