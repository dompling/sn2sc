<?php
$data = array (
  'callback' => '',
  'appkey' => '',
  'appid' => '',
  'open' => '',
  'scope' => 'get_user_info',
);
?>