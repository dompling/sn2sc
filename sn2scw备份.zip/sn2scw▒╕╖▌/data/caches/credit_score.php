<?php
$data = array (
  'credit_set' => 
  array (
    'rank' => 
    array (
      1 => 10,
      2 => 20,
      3 => 40,
      4 => 70,
      5 => 120,
      6 => 200,
      7 => 400,
      8 => 700,
      9 => 1200,
      10 => 1800,
      11 => 2600,
      12 => 4000,
      13 => 10000,
      14 => 30000,
      15 => 60000,
    ),
  ),
  'score' => 
  array (
    'rank' => 
    array (
      'register' => '+10',
      'login' => '+2',
      'information' => '+2',
      'coupon' => '+2',
      'group' => '+2',
      'goods' => '+2',
      'com_certify' => '+10',
      'per_certify' => '+10',
    ),
  ),
  'credit' => 
  array (
    'rank' => 
    array (
      'com_certify' => '+50',
      'per_certify' => '+50',
      'coin_credit' => '+10',
    ),
  ),
);
?>