<?php
$data = array (
  1 => 
  array (
    1 => 
    array (
      'words' => '遂宁二手车网',
      'url' => 'index.php',
      'image' => '/attachment/mobile_gg/1469676806dzt6z.jpg',
    ),
    3 => 
    array (
      'words' => '欢迎光临遂宁二手车网',
      'url' => 'index.php',
      'image' => '/attachment/mobile_gg/1469677858x6r1c.png',
    ),
  ),
  2 => 
  array (
    2 => 
    array (
      'words' => '疯狂猜车',
      'url' => 'index.php',
      'image' => '/attachment/mobile_gg/14696777801tuyl.jpg',
    ),
    4 => 
    array (
      'words' => '7天退换',
      'url' => 'index.php',
      'image' => '/attachment/mobile_gg/1469677887yuini.png',
    ),
  ),
);
?>