<?php
$data = array (
  'index' => 
  array (
    'txt' => 
    array (
      0 => 
      array (
        'name' => '遂宁政府网',
        'url' => 'http://www.suining.gov.cn',
      ),
      1 => 
      array (
        'name' => '遂宁人才网',
        'url' => 'http://www.snxcw.com/',
      ),
      2 => 
      array (
        'name' => '免费建网站',
        'url' => 'http://wsccms.top/regByPhone.do?inviteid=1395',
      ),
      3 => 
      array (
        'name' => '遂宁网站推广',
        'url' => 'http://www.snalkj.com',
      ),
      4 => 
      array (
        'name' => '服务器选购',
        'url' => 'http://idc.snalkj.com/',
      ),
      5 => 
      array (
        'name' => '优惠券购物网',
        'url' => 'http://www.158jyt.com/',
      ),
      6 => 
      array (
        'name' => '9.9元包邮',
        'url' => 'http://www.158jyt.com/index.php?r=nine&u=239788',
      ),
    ),
    'img' => '',
  ),
);
?>