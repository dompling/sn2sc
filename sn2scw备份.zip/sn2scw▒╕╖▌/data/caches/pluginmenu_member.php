<?php
$data = array (
  'news' => '资讯',
);
?>