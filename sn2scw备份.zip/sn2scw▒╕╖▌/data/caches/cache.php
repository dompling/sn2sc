<?php
$data = array (
  'site' => 
  array (
    'time' => '0',
    'open' => '0',
  ),
  'list' => 
  array (
    'time' => '0',
    'open' => '0',
  ),
  'info' => 
  array (
    'time' => '0',
    'open' => '0',
  ),
  'aboutus' => 
  array (
    'time' => '0',
    'open' => '0',
  ),
  'announce' => 
  array (
    'time' => '0',
    'open' => '0',
  ),
  'faq' => 
  array (
    'time' => '0',
    'open' => '0',
  ),
  'friendlink' => 
  array (
    'time' => '0',
    'open' => '0',
  ),
  'sitemap' => 
  array (
    'time' => '0',
    'open' => '0',
  ),
  'changecity' => 
  array (
    'time' => '0',
    'open' => '0',
  ),
);
?>