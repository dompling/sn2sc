<?php
$data = array (
  1 => 
  array (
    'catid' => '1',
    'catname' => '运动/户外/休闲',
    'color' => '',
    'if_view' => '2',
    'uri' => 'http://www.sn2scw.com/goods.php?catid=1',
    'children' => 
    array (
      10 => 
      array (
        'catid' => '10',
        'catname' => '运动服',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=10',
      ),
      11 => 
      array (
        'catid' => '11',
        'catname' => '野营',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=11',
      ),
      12 => 
      array (
        'catid' => '12',
        'catname' => '游泳用品',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=12',
      ),
      13 => 
      array (
        'catid' => '13',
        'catname' => '运动包',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=13',
      ),
      14 => 
      array (
        'catid' => '14',
        'catname' => '户外军品',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=14',
      ),
      15 => 
      array (
        'catid' => '15',
        'catname' => '健美健身',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=15',
      ),
      16 => 
      array (
        'catid' => '16',
        'catname' => '瑜珈用品',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=16',
      ),
      17 => 
      array (
        'catid' => '17',
        'catname' => '羽毛球',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=17',
      ),
      18 => 
      array (
        'catid' => '18',
        'catname' => '其它',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=18',
      ),
    ),
  ),
  2 => 
  array (
    'catid' => '2',
    'catname' => '女士服装/内衣',
    'color' => '',
    'if_view' => '2',
    'uri' => 'http://www.sn2scw.com/goods.php?catid=2',
    'children' => 
    array (
      19 => 
      array (
        'catid' => '19',
        'catname' => '衬衫',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=19',
      ),
      20 => 
      array (
        'catid' => '20',
        'catname' => '小吊带',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=20',
      ),
      21 => 
      array (
        'catid' => '21',
        'catname' => '韩版',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=21',
      ),
      22 => 
      array (
        'catid' => '22',
        'catname' => '牛仔裤',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=22',
      ),
      23 => 
      array (
        'catid' => '23',
        'catname' => '蕾丝雪纺',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=23',
      ),
      24 => 
      array (
        'catid' => '24',
        'catname' => '小外套',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=24',
      ),
      25 => 
      array (
        'catid' => '25',
        'catname' => '其它',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=25',
      ),
    ),
  ),
  3 => 
  array (
    'catid' => '3',
    'catname' => '男士服装与配件',
    'color' => '',
    'if_view' => '2',
    'uri' => 'http://www.sn2scw.com/goods.php?catid=3',
    'children' => 
    array (
      26 => 
      array (
        'catid' => '26',
        'catname' => '外套',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=26',
      ),
      27 => 
      array (
        'catid' => '27',
        'catname' => '西服',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=27',
      ),
      28 => 
      array (
        'catid' => '28',
        'catname' => '男鞋',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=28',
      ),
      29 => 
      array (
        'catid' => '29',
        'catname' => '衬衫',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=29',
      ),
      30 => 
      array (
        'catid' => '30',
        'catname' => '凉鞋',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=30',
      ),
      31 => 
      array (
        'catid' => '31',
        'catname' => '休闲包',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=31',
      ),
      32 => 
      array (
        'catid' => '32',
        'catname' => '皮带',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=32',
      ),
      33 => 
      array (
        'catid' => '33',
        'catname' => '男士内衣',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=33',
      ),
      34 => 
      array (
        'catid' => '34',
        'catname' => '男裤',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=34',
      ),
      35 => 
      array (
        'catid' => '35',
        'catname' => '其它',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=35',
      ),
    ),
  ),
  4 => 
  array (
    'catid' => '4',
    'catname' => '装潢/居家/家具',
    'color' => '',
    'if_view' => '2',
    'uri' => 'http://www.sn2scw.com/goods.php?catid=4',
    'children' => 
    array (
      36 => 
      array (
        'catid' => '36',
        'catname' => '时尚家饰',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=36',
      ),
      37 => 
      array (
        'catid' => '37',
        'catname' => '居家日用',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=37',
      ),
      38 => 
      array (
        'catid' => '38',
        'catname' => '家具',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=38',
      ),
      39 => 
      array (
        'catid' => '39',
        'catname' => '灯具',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=39',
      ),
      40 => 
      array (
        'catid' => '40',
        'catname' => '厨具',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=40',
      ),
      41 => 
      array (
        'catid' => '41',
        'catname' => '装潢卫浴',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=41',
      ),
      42 => 
      array (
        'catid' => '42',
        'catname' => '文具天文',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=42',
      ),
      43 => 
      array (
        'catid' => '43',
        'catname' => '其它',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=43',
      ),
    ),
  ),
  5 => 
  array (
    'catid' => '5',
    'catname' => '电器/厨房用品/保健',
    'color' => '',
    'if_view' => '2',
    'uri' => 'http://www.sn2scw.com/goods.php?catid=5',
    'children' => 
    array (
      44 => 
      array (
        'catid' => '44',
        'catname' => '厨房用品',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=44',
      ),
      45 => 
      array (
        'catid' => '45',
        'catname' => '卫生保健',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=45',
      ),
      46 => 
      array (
        'catid' => '46',
        'catname' => '个人护理',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=46',
      ),
      47 => 
      array (
        'catid' => '47',
        'catname' => '卫浴电器',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=47',
      ),
      48 => 
      array (
        'catid' => '48',
        'catname' => '其它',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=48',
      ),
    ),
  ),
  6 => 
  array (
    'catid' => '6',
    'catname' => '汽车/摩托车/自行车',
    'color' => '',
    'if_view' => '2',
    'uri' => 'http://www.sn2scw.com/goods.php?catid=6',
    'children' => 
    array (
      49 => 
      array (
        'catid' => '49',
        'catname' => '摩托车',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=49',
      ),
      50 => 
      array (
        'catid' => '50',
        'catname' => '自行车',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=50',
      ),
      51 => 
      array (
        'catid' => '51',
        'catname' => '汽车',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=51',
      ),
      52 => 
      array (
        'catid' => '52',
        'catname' => 'GPS定位',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=52',
      ),
      53 => 
      array (
        'catid' => '53',
        'catname' => '车内饰',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=53',
      ),
      54 => 
      array (
        'catid' => '54',
        'catname' => '其它',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=54',
      ),
    ),
  ),
  7 => 
  array (
    'catid' => '7',
    'catname' => '珠宝/饰品/手表/眼镜',
    'color' => '',
    'if_view' => '2',
    'uri' => 'http://www.sn2scw.com/goods.php?catid=7',
    'children' => 
    array (
      55 => 
      array (
        'catid' => '55',
        'catname' => '手表',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=55',
      ),
      56 => 
      array (
        'catid' => '56',
        'catname' => '太阳眼镜',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=56',
      ),
      57 => 
      array (
        'catid' => '57',
        'catname' => '流行饰品',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=57',
      ),
      58 => 
      array (
        'catid' => '58',
        'catname' => '纯银',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=58',
      ),
      59 => 
      array (
        'catid' => '59',
        'catname' => '钻石水晶',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=59',
      ),
      60 => 
      array (
        'catid' => '60',
        'catname' => '黄金',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=60',
      ),
      61 => 
      array (
        'catid' => '61',
        'catname' => '珍珠翡翠',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=61',
      ),
      62 => 
      array (
        'catid' => '62',
        'catname' => '其它',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=62',
      ),
    ),
  ),
  8 => 
  array (
    'catid' => '8',
    'catname' => '电脑/网络/办公',
    'color' => '',
    'if_view' => '2',
    'uri' => 'http://www.sn2scw.com/goods.php?catid=8',
    'children' => 
    array (
      63 => 
      array (
        'catid' => '63',
        'catname' => '整机',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=63',
      ),
      64 => 
      array (
        'catid' => '64',
        'catname' => '笔记本',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=64',
      ),
      65 => 
      array (
        'catid' => '65',
        'catname' => '显示器',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=65',
      ),
      66 => 
      array (
        'catid' => '66',
        'catname' => '软件',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=66',
      ),
      67 => 
      array (
        'catid' => '67',
        'catname' => '硬盘/移动硬盘',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=67',
      ),
      68 => 
      array (
        'catid' => '68',
        'catname' => '键盘/鼠标',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=68',
      ),
      69 => 
      array (
        'catid' => '69',
        'catname' => '其它',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=69',
      ),
    ),
  ),
  9 => 
  array (
    'catid' => '9',
    'catname' => '特价机票/门票旅游/酒店',
    'color' => '',
    'if_view' => '2',
    'uri' => 'http://www.sn2scw.com/goods.php?catid=9',
    'children' => 
    array (
      70 => 
      array (
        'catid' => '70',
        'catname' => '特惠酒店',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=70',
      ),
      72 => 
      array (
        'catid' => '72',
        'catname' => '旅游卡券',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=72',
      ),
      73 => 
      array (
        'catid' => '73',
        'catname' => '酒店客栈',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=73',
      ),
      74 => 
      array (
        'catid' => '74',
        'catname' => '其它',
        'if_view' => '2',
        'color' => NULL,
        'uri' => 'http://www.sn2scw.com/goods.php?catid=74',
      ),
    ),
  ),
);
?>