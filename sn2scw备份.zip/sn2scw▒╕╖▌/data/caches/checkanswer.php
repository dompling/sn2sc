<?php
$data = array (
  6 => 
  array (
    'id' => '6',
    'question' => '5+8=?',
    'answer' => '13',
  ),
  5 => 
  array (
    'id' => '5',
    'question' => '2+5=?',
    'answer' => '7',
  ),
  2 => 
  array (
    'id' => '2',
    'question' => '本站名称[答案:遂宁二手车网]',
    'answer' => '遂宁二手车网',
  ),
  1 => 
  array (
    'id' => '1',
    'question' => '2+3=?',
    'answer' => '5',
  ),
);
?>