<?php
$data = array (
  6 => 
  array (
    'corpid' => '6',
    'corpname' => '二手车商家',
    'uri' => '/corporation.php?catid=6',
  ),
  7 => 
  array (
    'corpid' => '7',
    'corpname' => '4S店商家',
    'uri' => '/corporation.php?catid=7',
  ),
  8 => 
  array (
    'corpid' => '8',
    'corpname' => '汽修厂',
    'uri' => '/corporation.php?catid=8',
  ),
  9 => 
  array (
    'corpid' => '9',
    'corpname' => '汽车配件',
    'uri' => '/corporation.php?catid=9',
  ),
  10 => 
  array (
    'corpid' => '10',
    'corpname' => '物流公司',
    'uri' => '/corporation.php?catid=10',
  ),
  67 => 
  array (
    'corpid' => '67',
    'corpname' => '货运出租',
    'uri' => '/corporation.php?catid=67',
  ),
  68 => 
  array (
    'corpid' => '68',
    'corpname' => '租赁公司',
    'uri' => '/corporation.php?catid=68',
  ),
  69 => 
  array (
    'corpid' => '69',
    'corpname' => '汽车美容',
    'uri' => '/corporation.php?catid=69',
  ),
  70 => 
  array (
    'corpid' => '70',
    'corpname' => '加汽加油',
    'uri' => '/corporation.php?catid=70',
  ),
  71 => 
  array (
    'corpid' => '71',
    'corpname' => '停车场',
    'uri' => '/corporation.php?catid=71',
  ),
  72 => 
  array (
    'corpid' => '72',
    'corpname' => '代驾陪驾',
    'uri' => '/corporation.php?catid=72',
  ),
  73 => 
  array (
    'corpid' => '73',
    'corpname' => '拖车救援',
    'uri' => '/corporation.php?catid=73',
  ),
  74 => 
  array (
    'corpid' => '74',
    'corpname' => '汽车轮胎',
    'uri' => '/corporation.php?catid=74',
  ),
  75 => 
  array (
    'corpid' => '75',
    'corpname' => '汽车驾校',
    'uri' => '/corporation.php?catid=75',
  ),
);
?>