<?php
$data = array (
  '5umb' => 
  array (
    'id' => '5',
    'flag' => '5umb',
    'customtype' => 'info',
    'parameter' => 
    array (
      'jstemplate' => '<li>{title} - {link}</li>',
      'items' => '',
      'maxlength' => '',
      'ids' => '',
      'keyword' => '',
      'newwindow' => '0',
      'orderby' => 'dateline',
      'jscharset' => '0',
    ),
  ),
  'asdqwe' => 
  array (
    'id' => '2',
    'flag' => 'asdqwe',
    'customtype' => 'news',
    'parameter' => 
    array (
      'jstemplate' => '<li>{title}{link}</li>',
      'catid' => '',
      'items' => '',
      'maxlength' => '',
      'newwindow' => '0',
      'orderby' => 'dateline',
      'jscharset' => '0',
    ),
  ),
  '329e' => 
  array (
    'id' => '3',
    'flag' => '329e',
    'customtype' => 'store',
    'parameter' => 
    array (
      'jstemplate' => '<li>{tname}{link}</li>',
      'catid' => '',
      'levelid' => '',
      'items' => '',
      'maxlength' => '',
      'newwindow' => '0',
      'orderby' => 'dateline',
      'jscharset' => '0',
    ),
  ),
  '4nmv' => 
  array (
    'id' => '4',
    'flag' => '4nmv',
    'customtype' => 'goods',
    'parameter' => 
    array (
      'jstemplate' => '<li>{goodsname}{link}</li>',
      'catid' => '',
      'items' => '',
      'maxlength' => '',
      'special' => 
      array (
        0 => '',
      ),
      'newwindow' => '0',
      'orderby' => 'dateline',
      'jscharset' => '0',
    ),
  ),
);
?>