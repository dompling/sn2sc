<?php
$data = array (
  26 => 
  array (
    'identifier' => 
    array (
      0 => 'store_type',
      1 => 'acreage',
    ),
  ),
  25 => 
  array (
    'identifier' => 
    array (
      0 => 'acreage',
      1 => 'prices',
    ),
  ),
  24 => 
  array (
    'identifier' => 
    array (
      0 => 'position',
      1 => 'acreage',
      2 => 'min_rent',
    ),
  ),
  23 => 
  array (
    'identifier' => 
    array (
      0 => 'position',
      1 => 'rent_type',
      2 => 'room_type',
      3 => 'mini_rent',
    ),
  ),
  22 => 
  array (
    'identifier' => 
    array (
      0 => 'position',
      1 => 'room_type',
      2 => 'prices',
      3 => 'acreage',
    ),
  ),
  21 => 
  array (
    'identifier' => 
    array (
      0 => 'pet_class',
      1 => 'price',
    ),
  ),
  20 => 
  array (
    'identifier' => 
    array (
      0 => 'dog_breeds',
      1 => 'animal_sex',
      2 => 'price',
      3 => 'from',
    ),
  ),
  19 => 
  array (
    'identifier' => 
    array (
      0 => 'sex',
    ),
  ),
  16 => 
  array (
    'identifier' => 
    array (
      0 => 'prices',
      1 => 'from',
    ),
  ),
  15 => 
  array (
    'identifier' => 
    array (
      0 => 'prices',
      1 => 'from',
    ),
  ),
  14 => 
  array (
    'identifier' => 
    array (
      0 => 'carpool_type',
      1 => 'price',
    ),
  ),
  13 => 
  array (
    'identifier' => 
    array (
      0 => 'price',
      1 => 'jibenpeizhi',
      2 => 'gaojipeizhi',
      3 => 'from',
    ),
  ),
  12 => 
  array (
    'identifier' => 
    array (
      0 => 'prices',
      1 => 'jibenpeizhi',
      2 => 'gaojipeizhi',
      3 => 'from',
    ),
  ),
  11 => 
  array (
    'identifier' => 
    array (
      0 => 'price',
      1 => 'from',
      2 => 'jibenpeizhi',
      3 => 'gaojipeizhi',
    ),
  ),
  10 => 
  array (
    'identifier' => 
    array (
      0 => 'tuition',
    ),
  ),
  9 => 
  array (
    'identifier' => 
    array (
      0 => 'sex',
      1 => 'education',
      2 => 'graduate',
    ),
  ),
  8 => 
  array (
    'identifier' => 
    array (
      0 => 'day_salary',
    ),
  ),
  7 => 
  array (
    'identifier' => 
    array (
      0 => 'salary',
      1 => 'education',
      2 => 'fuli',
    ),
  ),
  6 => 
  array (
    'identifier' => 
    array (
      0 => 'pc_brand',
      1 => 'price',
      2 => 'from',
    ),
  ),
  27 => 
  array (
    'identifier' => 
    array (
      0 => 'motobrand',
      1 => 'price',
      2 => 'from',
    ),
  ),
  28 => 
  array (
    'identifier' => 
    array (
      0 => 'mbrand',
      1 => 'price',
      2 => 'from',
    ),
  ),
);
?>