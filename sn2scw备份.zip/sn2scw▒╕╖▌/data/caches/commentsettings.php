<?php
$data = array (
  'information' => '0',
  'news' => '0',
  'store' => '0',
);
?>