<?php
$data = array (
  'callback' => '',
  'appsecret' => '',
  'appid' => '',
  'open' => '',
  'scope' => 'get_user_info',
);
?>