<?php
$data = array (
  'jsrefdomains' => '',
  'jsdateformat' => 'Y/m/d',
  'jscachelife' => '0',
  'jsstatus' => '1',
);
?>