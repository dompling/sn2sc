<?php
$data = array (
  228 => 
  array (
    'catid' => '228',
    'catname' => '各类二手车',
    'color' => '',
    'if_view' => '2',
    'dir_typename' => 'ershoujiaoche',
    'uri' => 'http://www.sn2scw.com/category.php?catid=228',
    'usecoin' => '0',
    'icon' => '',
    'children' => 
    array (
      253 => 
      array (
        'catid' => '253',
        'catname' => '二手轿车',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => '2shoujiaoche',
        'uri' => 'http://www.sn2scw.com/category.php?catid=253',
        'usecoin' => '0',
      ),
      254 => 
      array (
        'catid' => '254',
        'catname' => '货车/工程车',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'huoche_gongchengche',
        'uri' => 'http://www.sn2scw.com/category.php?catid=254',
        'usecoin' => '0',
      ),
      255 => 
      array (
        'catid' => '255',
        'catname' => '面包车/客车',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'mianbaoche_keche',
        'uri' => 'http://www.sn2scw.com/category.php?catid=255',
        'usecoin' => '0',
      ),
      256 => 
      array (
        'catid' => '256',
        'catname' => '皮卡车',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'pikache',
        'uri' => 'http://www.sn2scw.com/category.php?catid=256',
        'usecoin' => '0',
      ),
      257 => 
      array (
        'catid' => '257',
        'catname' => '农用车',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'nongyongche',
        'uri' => 'http://www.sn2scw.com/category.php?catid=257',
        'usecoin' => '0',
      ),
      258 => 
      array (
        'catid' => '258',
        'catname' => '机械工程车',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'jixiegongchengche',
        'uri' => 'http://www.sn2scw.com/category.php?catid=258',
        'usecoin' => '0',
      ),
      259 => 
      array (
        'catid' => '259',
        'catname' => '其他',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'qita',
        'uri' => 'http://www.sn2scw.com/category.php?catid=259',
        'usecoin' => '0',
      ),
    ),
  ),
  264 => 
  array (
    'catid' => '264',
    'catname' => '4s店新车',
    'color' => '',
    'if_view' => '2',
    'dir_typename' => '4sdianxinche',
    'uri' => 'http://www.sn2scw.com/category.php?catid=264',
    'usecoin' => '0',
    'icon' => '',
    'children' => 
    array (
      277 => 
      array (
        'catid' => '277',
        'catname' => '4s店新车',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => '4sdianxinche',
        'uri' => 'http://www.sn2scw.com/category.php?catid=277',
        'usecoin' => '0',
      ),
    ),
  ),
  265 => 
  array (
    'catid' => '265',
    'catname' => '汽修厂',
    'color' => '',
    'if_view' => '2',
    'dir_typename' => 'qixiuchang',
    'uri' => 'http://www.sn2scw.com/category.php?catid=265',
    'usecoin' => '0',
    'icon' => '',
    'children' => 
    array (
      278 => 
      array (
        'catid' => '278',
        'catname' => '汽修厂',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'qixiuchang',
        'uri' => 'http://www.sn2scw.com/category.php?catid=278',
        'usecoin' => '0',
      ),
    ),
  ),
  266 => 
  array (
    'catid' => '266',
    'catname' => '汽车配件',
    'color' => '',
    'if_view' => '2',
    'dir_typename' => 'qichepeijian',
    'uri' => 'http://www.sn2scw.com/category.php?catid=266',
    'usecoin' => '0',
    'icon' => '',
    'children' => 
    array (
      279 => 
      array (
        'catid' => '279',
        'catname' => '汽车配件',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'qichepeijian',
        'uri' => 'http://www.sn2scw.com/category.php?catid=279',
        'usecoin' => '0',
      ),
    ),
  ),
  267 => 
  array (
    'catid' => '267',
    'catname' => '汽车轮胎',
    'color' => '',
    'if_view' => '2',
    'dir_typename' => 'qichelt',
    'uri' => 'http://www.sn2scw.com/category.php?catid=267',
    'usecoin' => '0',
    'icon' => '',
    'children' => 
    array (
      280 => 
      array (
        'catid' => '280',
        'catname' => '汽车轮胎',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'qicheluntai',
        'uri' => 'http://www.sn2scw.com/category.php?catid=280',
        'usecoin' => '0',
      ),
    ),
  ),
  268 => 
  array (
    'catid' => '268',
    'catname' => '洗车美容',
    'color' => '',
    'if_view' => '2',
    'dir_typename' => 'xichemeirong',
    'uri' => 'http://www.sn2scw.com/category.php?catid=268',
    'usecoin' => '0',
    'icon' => '',
    'children' => 
    array (
      281 => 
      array (
        'catid' => '281',
        'catname' => '洗车美容',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'xichemeirong',
        'uri' => 'http://www.sn2scw.com/category.php?catid=281',
        'usecoin' => '0',
      ),
    ),
  ),
  269 => 
  array (
    'catid' => '269',
    'catname' => '物流公司',
    'color' => '',
    'if_view' => '2',
    'dir_typename' => 'wuliugongsi',
    'uri' => 'http://www.sn2scw.com/category.php?catid=269',
    'usecoin' => '0',
    'icon' => '',
    'children' => 
    array (
      282 => 
      array (
        'catid' => '282',
        'catname' => '物流公司',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'wuliugongsi',
        'uri' => 'http://www.sn2scw.com/category.php?catid=282',
        'usecoin' => '0',
      ),
    ),
  ),
  270 => 
  array (
    'catid' => '270',
    'catname' => '个体货运',
    'color' => '',
    'if_view' => '2',
    'dir_typename' => 'getihuoyun',
    'uri' => 'http://www.sn2scw.com/category.php?catid=270',
    'usecoin' => '0',
    'icon' => '',
    'children' => 
    array (
      283 => 
      array (
        'catid' => '283',
        'catname' => '个体货运',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'getihuoyun',
        'uri' => 'http://www.sn2scw.com/category.php?catid=283',
        'usecoin' => '0',
      ),
    ),
  ),
  271 => 
  array (
    'catid' => '271',
    'catname' => '租赁公司',
    'color' => '',
    'if_view' => '2',
    'dir_typename' => 'zulingongsi',
    'uri' => 'http://www.sn2scw.com/category.php?catid=271',
    'usecoin' => '0',
    'icon' => '',
    'children' => 
    array (
      284 => 
      array (
        'catid' => '284',
        'catname' => '租赁公司',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'zulingongsi',
        'uri' => 'http://www.sn2scw.com/category.php?catid=284',
        'usecoin' => '0',
      ),
    ),
  ),
  290 => 
  array (
    'catid' => '290',
    'catname' => '其他',
    'color' => '',
    'if_view' => '2',
    'dir_typename' => 'qita',
    'uri' => 'http://www.sn2scw.com/category.php?catid=290',
    'usecoin' => '0',
    'icon' => '',
    'children' => 
    array (
      291 => 
      array (
        'catid' => '291',
        'catname' => '加油加气',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'jiayoujiaqi',
        'uri' => 'http://www.sn2scw.com/category.php?catid=291',
        'usecoin' => '0',
      ),
      292 => 
      array (
        'catid' => '292',
        'catname' => '停车场',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'tingchechang',
        'uri' => 'http://www.sn2scw.com/category.php?catid=292',
        'usecoin' => '0',
      ),
      293 => 
      array (
        'catid' => '293',
        'catname' => '拖车救援',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'tuochejiuyuan',
        'uri' => 'http://www.sn2scw.com/category.php?catid=293',
        'usecoin' => '0',
      ),
      294 => 
      array (
        'catid' => '294',
        'catname' => '代驾陪驾',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'daijiapeijia',
        'uri' => 'http://www.sn2scw.com/category.php?catid=294',
        'usecoin' => '0',
      ),
      295 => 
      array (
        'catid' => '295',
        'catname' => '汽车驾校',
        'if_view' => '2',
        'color' => '',
        'dir_typename' => 'qichejiaxiao',
        'uri' => 'http://www.sn2scw.com/category.php?catid=295',
        'usecoin' => '0',
      ),
    ),
  ),
);
?>