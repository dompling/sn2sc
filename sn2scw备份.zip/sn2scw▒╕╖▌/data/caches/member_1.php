<?php
$data = array (
  'id' => '1',
  'levelname' => '二手车会员 ',
  'ifsystem' => '1',
  'purviews' => 'purview_info,purview_pay,purview_avatar,purview_shoucang,purview_certify,purview_pm,purview_levelup,purview_password,purview_shop,purview_comment,purview_album,purview_document,purview_banner',
  'money_own' => '5',
  'perday_maxpost' => '5',
  'allow_tpl' => 
  array (
    1 => 
    array (
      'tpl_name' => '蓝色主题',
      'tpl_path' => 'blue',
    ),
    2 => 
    array (
      'tpl_name' => '橙红主题',
      'tpl_path' => 'orange',
    ),
    4 => 
    array (
      'tpl_name' => '绿色主题',
      'tpl_path' => 'green',
    ),
    6 => 
    array (
      'tpl_name' => '紫色主题',
      'tpl_path' => 'purple',
    ),
    7 => 
    array (
      'tpl_name' => '粉色主题',
      'tpl_path' => 'pink',
    ),
  ),
  'member_contact' => '0',
  'signin_notice' => '0',
  'signin_del' => '0',
  'signin_view' => '0',
  'moneysettings' => 'N;',
);
?>