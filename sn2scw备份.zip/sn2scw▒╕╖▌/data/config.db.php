<?php

$charset    = "utf-8";

//系统字符集编码

$dbcharset = "utf8";

//数据库字符集编码

$db_host    = "localhost";

//数据库服务器地址，一般为localhost

$db_name    = "sn2scw";

//使用的数据库名称

$db_user    = "sn2scw";

//数据库帐号

$db_pass    = "wh121876673";

//数据库密码

$db_mymps   = "my_";

//数据库前缀

$db_intype  = "";

$cookiepre = "rjmp_";

//cookies加密前缀

$cookiedomain = ".sn2scw.com";

$cookiepath = "/";

?>