<?php
!(defined('IN_MYMPS')) && exit('FORBIDDEN');